import imghdr
import os

from flask import Flask, request, render_template, send_file, redirect

app = Flask(__name__)
app.config['BASE_DIR'] = os.path.abspath(os.path.dirname(__file__))
app.secret_key = 'asdasdasdasasdasdasdjdoijqowdijqowidj'
app.config['UPLOAD_FOLDER'] = os.path.join(app.config['BASE_DIR'], 'uploads')




def validate_image(file):
    if imghdr.what('unused', file.read()) is None:
        return False
    else:
        return True


@app.route('/')
def index_page():
    f = open(os.path.join(app.config['UPLOAD_FOLDER']) + '/bd.txt', 'r')
    memes = f.readlines()
    f.close()
    return render_template('main.html',memes=memes)


@app.route('/upload', methods=['POST', 'GET'])
def upload():
    if request.method == 'POST':
        print (request.files)
        file = request.files['file']
        name = request.form['name']
        check = validate_image(file)
        if check:
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], name + '.jpg'))
            bd = open(os.path.join(app.config['UPLOAD_FOLDER']) + '/bd.txt', 'a')
            bd.write(name+'.jpg'+chr(10)+chr(13))
            bd.close()
        else:
            return "bad file"
        return redirect('/')
    else:
        return render_template('upload.html')


@app.route('/find')
def find():
    mem = request.args['mem']
    return send_file(os.path.join(app.config['UPLOAD_FOLDER']) + "/"+str(mem))


if __name__ == '__main__':
    app.threaded = True
    app.processes = 50
    app.run(port=8060, debug=True)
